$BD::Enabled = false;
$BD::Admins = false;
$BD::Time = 10; // minutes
$BD::Reason = "YOU ARE DEAD";
function serverCmdToggleBD( %cl )
{
    if ( %cl.isAdmin || %cl.isSuperAdmin )
    {
        $BD::Enabled = !$BD::Enabled;
        messageAll( 'MsgUploadDone', "\c3" @ %cl.name @ " \c0has " @ ( $BD::Enabled ? "en" : "dis" ) @ "abled \c3Ban on Death\c0." );
    }
}
package bd_package
{
    function gameConnection::onDeath( %this, %a, %b, %c, %d, %e, %f, %g )
    {
        parent::onDeath( %this, %a, %b, %c, %d, %e, %f, %g );
        
        if ( $BD::Enabled && ( %this.isAdmin || %this.isSuperAdmin ? $BD::Admins : true ) )
        {
            if($BD::Time == 0)
                %this.delete($BD::Reason);
            else
                schedule( 100, 0, "banBLID", %this.getBLID(), $BD::Time, $BD::Reason );
        }
    }
};
activatePackage( "bd_package" );